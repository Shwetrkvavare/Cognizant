package com.java.project;

//import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RediffMail {

	static WebDriver driver;
	public static void initializingDriver(int choice) {
		
		 if(choice==1) {
			  driver = new ChromeDriver();
		 }
		 else if(choice==2) {
			 driver = new EdgeDriver();
		 }
		 
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
		driver.manage().window().maximize();		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	public static void createNewAccount(){
		driver.findElement(By.linkText("Create a new account")).click();
	}
	
	public static void enterDetails(){
		driver.findElement(By.cssSelector("input[type='text']")).sendKeys("Kamal");
		driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[7]/td[3]/input[1]")).sendKeys("Kamal1234");
		driver.findElement(By.cssSelector("input[value='Check availability']")).click();
	}
	
	public static void checkAvailability(){
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='recommend_text']//table")));
		  
		  List<WebElement> radioBtns = driver.findElements(By.id("radio_login"));
			//System.out.println(radioBtns);
			//radioBtns.get(0).click();
		  radioBtns.get((int)Math.floor(Math.random()*radioBtns.size())).click();
	}
	
	public static void enterPassword(){
		driver.findElement(By.id("newpasswd")).sendKeys("Kamal@1234");
		
		driver.findElement(By.id("newpasswd1")).sendKeys("Kamal@1234");
	}
	
	public static void selectCheckBox(){
		driver.findElement(By.cssSelector("input.nomargin")).click();
	}
	
	public static void selectDob(){
		WebElement daysDropdown = driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[1]"));
		Select daysSelect = new Select(daysDropdown);
		WebElement monthDropdown = driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[2]"));
		Select monthSelect = new Select(monthDropdown);
		WebElement yearDropdown = driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[3]"));
		Select yearSelect = new Select(yearDropdown);
		
		daysSelect.selectByValue("20");
		monthSelect.selectByVisibleText("JUN");
		yearSelect.selectByValue("2000");
	}
	
	public static void selectCountry(){
		driver.findElement(By.id("country")).click();
		WebElement countryDropdown = driver.findElement(By.id("country"));
		Select countrySelect = new Select(countryDropdown);
		List<WebElement> countryOptions = countrySelect.getOptions();
		System.out.println("Total count of countries: "+countryOptions.size());
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		for(int i=0;i<countryOptions.size();i++) {
			String countryDisplay = countryOptions.get(i).getText();
			System.out.println(countryDisplay);
		}
	}
	
	public static void countrySelected(){
		WebElement countryDropdown = driver.findElement(By.id("country"));
		  Select countrySelect = new Select(countryDropdown);
		  countrySelect.selectByVisibleText("India");
		  List<WebElement> countryOptions = countrySelect.getOptions();
		  
		  String selectedValue = countryDropdown.getAttribute("value");
		  
		  String act_country = "";
		  String exp_country = "India";
		
			for(WebElement ele : countryOptions) {
				if(ele.getAttribute("value").equals(selectedValue)) {
					act_country = ele.getText();
					System.out.println("Country Selected: "+ele.getText());
					break;
				}
			}
	}
	
	public static void validateCountrySelected(){
		WebElement countryDropdown = driver.findElement(By.id("country"));
		  Select countrySelect = new Select(countryDropdown);
		  countrySelect.selectByVisibleText("India");
		  countryDropdown.sendKeys(Keys.ESCAPE);
		  List<WebElement> countryOptions = countrySelect.getOptions();
		  
		  String selectedValue = countryDropdown.getAttribute("value");
		  String act_country = "";
		  String exp_country = "India";
		  
		
			for(WebElement ele : countryOptions) {
				if(ele.getAttribute("value").equals(selectedValue)) {
					act_country = ele.getText();				
					break;
				}
			}
			//assertTrue(act_country.matches(exp_country));
			if(act_country.equals(exp_country)) System.out.println("Test Passed");
			else System.out.println("Failed");
			
	}
	
	
	public static void quitBrowser(){
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5000));
		driver.quit();
	}
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose your Browser: 1. Chrome 2. Edge");
		int choice;
		Thread.sleep(3000);
        while(true) {
        	choice = sc.nextInt();
        	if(choice == 1 || choice == 2) {
        		break;
        	}
        	else {
        		System.out.println("Enter 1 or 2 : ");
        	}
        }
        
        initializingDriver(choice);
        createNewAccount();
        enterDetails();
        checkAvailability();
        enterPassword();
        selectCheckBox();
        selectDob();
        selectCountry();
        countrySelected();
        validateCountrySelected();
        quitBrowser();

	}

}

