import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class NewTest2 {
	WebDriver driver;
	JavascriptExecutor jse;
	WebDriverWait wait;
	String parentWinHandle;
	String childOneWinHandle;
	String childThreeWinHandle;

	@BeforeTest
	public void beforeTest() {
		driver = new ChromeDriver();
		driver.get("https://us.trip.com/?locale=en-US&curr=USD");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Test(priority=1)
	public void cruiseTab() {
		driver.findElement(By.id("header_action_nav_cruises")).click();
	}
	
	@Test(priority=2)
	public void selectCruise() throws InterruptedException {
		Thread.sleep(3000);
		WebElement scroll1 = driver.findElement(By.cssSelector("h2.popular-title"));
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView()", scroll1);
		Thread.sleep(3000);
		
		
		while(true) {
			List<WebElement> cruiseLine = driver.findElements(By.xpath("//h3[@class='product-title']"));
			System.out.println("Total Cruise Lines: " + cruiseLine.size());
			cruiseLine.get((int)Math.floor(Math.random()*cruiseLine.size())).click();
			//driver.findElement(By.xpath("//*[@id=\"ibucru-10650039176-cruise-product-7-42637-2\"]/div[1]")).click();
			WebElement ele = null;
			try {
				ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.modal-bd")));
				driver.findElement(By.cssSelector("button.cru-btn")).click();
			}catch(Exception e) {
				
			}
			if(ele == null)
				break;
		}
	}
	
	@Test(priority=3)
	public void cruiseName() {
		 parentWinHandle = driver.getWindowHandle();
		 childOneWinHandle = "";
		for(String winHandle : driver.getWindowHandles()) {
			if(!parentWinHandle.equals(winHandle)) {
				childOneWinHandle = winHandle;
				driver.switchTo().window(childOneWinHandle);
			}
		}
		
		WebElement title = driver.findElement(By.cssSelector("h2.product-title"));
		System.out.println(title.getText());
		WebElement cruise = driver.findElement(By.cssSelector("span.cruise"));
		System.out.println("Cruise Name: "+cruise.getText());
		WebElement company = driver.findElement(By.cssSelector("span.company"));
		System.out.println("Company: "+company.getText());
		List<WebElement> dates = driver.findElements(By.cssSelector("div.depart-item"));
		for(int i=0;i<dates.size();i++) {
			String b = dates.get(i).getText();
			System.out.println(b);
		}
	}
	
	@Test(priority=4)
	public void clickShipDetails() throws InterruptedException {
		WebElement scroll2 = driver.findElement(By.cssSelector("span.tab-text"));
		jse.executeScript("arguments[0].scrollIntoView()", scroll2);
		Thread.sleep(3000);
		driver.findElement(By.linkText("Ship Details")).click();
	}
	@Test(priority=5)
	public void getShipDetails() throws InterruptedException {
	    childThreeWinHandle = "";
		for(String winHandle : driver.getWindowHandles()) {
			if(!parentWinHandle.equals(winHandle) && !childOneWinHandle.equals(winHandle) && !childThreeWinHandle.equals(winHandle)) {
				childThreeWinHandle=winHandle;
				driver.switchTo().window(childThreeWinHandle);
			}
		}
		
//		driver.get("https://us.trip.com/cruises/ship-ncl-norwegian-sky-110");
		WebElement scroll3 = driver.findElement(By.cssSelector("div.ship-panel-title"));
//		String name = scroll3.getText();
//		System.out.println("Crusie Name: "+name);
		jse.executeScript("arguments[0].scrollIntoView()", scroll3);
		Thread.sleep(3000);
		List<WebElement> r =driver.findElements(By.cssSelector("span.parame-item"));
		//List<WebElement> r =driver.findElements(By.xpath("//div[@class='poi-parames']/span[@class='parame-item']"));
		//System.out.println("Num: "+r.size());
		for(int i=0;i<r.size();i++) {
			String a = r.get(i).getText();
			if(a.matches("(?i)(Decks|Crew|Renovated in|Passengers|Guest|Entered Service).*"))
			System.out.println(a);			
		}
	}
	

	@AfterTest
	public void afterTest() throws InterruptedException {
		Thread.sleep(2000);
		driver.quit();
	}

}
