import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;

import java.time.Duration;
import java.util.List;
import static org.testng.Assert.assertTrue;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class NewTest {
	WebDriver driver;
	String username;
	String emailId;
	String password;
	
  @BeforeTest
  public void beforeTest() {
	  driver = new ChromeDriver();
	  readFromExcel();
	  driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  
  }
	
  @Test(priority=1)
  public void f() {
	 //System.out.println("found");
	 driver.findElement(By.linkText("Create a new account")).click();	 
  } 
  
  @Test(priority=2)
  public void f1() {
	  driver.findElement(By.cssSelector("input[type='text']")).sendKeys(username);
	  driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[7]/td[3]/input[1]")).sendKeys(emailId);
	  driver.findElement(By.cssSelector("input[value='Check availability']")).click();
	  
  }
  
  @Test(priority=3)
  public void f2() {
	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='recommend_text']//table")));
	  
	  List<WebElement> radioBtns = driver.findElements(By.id("radio_login"));
		//System.out.println(radioBtns);
		//radioBtns.get(0).click();
		radioBtns.get((int)Math.floor(Math.random()*radioBtns.size())).click();
  }
  
  @Test(priority=4)
  public void f3() {
	  driver.findElement(By.id("newpasswd")).sendKeys(password);
		
	  driver.findElement(By.id("newpasswd1")).sendKeys(password);
	  
  }
  
  @Test(priority=5)
  public void f4() {
	  driver.findElement(By.cssSelector("input.nomargin")).click();
	  
  }
  
  @Test(priority=6)
  public void f5() {
	  	WebElement daysDropdown = driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[1]"));
		Select daysSelect = new Select(daysDropdown);
		WebElement monthDropdown = driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[2]"));
		Select monthSelect = new Select(monthDropdown);
		WebElement yearDropdown = driver.findElement(By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[3]"));
		Select yearSelect = new Select(yearDropdown);
		
		daysSelect.selectByValue("20");
		monthSelect.selectByVisibleText("JUN");
		yearSelect.selectByValue("2000");
		
		
  }
  
  @Test(priority=7)
  public void f6() {
	  	driver.findElement(By.id("country")).click();
		WebElement countryDropdown = driver.findElement(By.id("country"));
		Select countrySelect = new Select(countryDropdown);
		List<WebElement> countryOptions = countrySelect.getOptions();
		System.out.println("Total count of countries: "+countryOptions.size());
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		for(int i=0;i<countryOptions.size();i++) {
			String countryDisplay = countryOptions.get(i).getText();
			System.out.println(countryDisplay);
		}
	  
  }
  
  @Test(priority=8)
  public void f7() {
	  WebElement countryDropdown = driver.findElement(By.id("country"));
	  Select countrySelect = new Select(countryDropdown);
	  countrySelect.selectByVisibleText("India");
	  List<WebElement> countryOptions = countrySelect.getOptions();
	  
	  String selectedValue = countryDropdown.getAttribute("value");
	  
	  String act_country = "";
	  String exp_country = "India";
	
		for(WebElement ele : countryOptions) {
			if(ele.getAttribute("value").equals(selectedValue)) {
				act_country = ele.getText();
				System.out.println("Country Selected: "+ele.getText());
				break;
			}
		}
	  
  
  }
  
  @Test(priority=9)
  public void f8() {
	  WebElement countryDropdown = driver.findElement(By.id("country"));
	  Select countrySelect = new Select(countryDropdown);
	  countrySelect.selectByVisibleText("India");
	  countryDropdown.sendKeys(Keys.ESCAPE);
	  List<WebElement> countryOptions = countrySelect.getOptions();
	  
	  String selectedValue = countryDropdown.getAttribute("value");
	  String act_country = "";
	  String exp_country = "India";
	  
	
		for(WebElement ele : countryOptions) {
			if(ele.getAttribute("value").equals(selectedValue)) {
				act_country = ele.getText();				
				break;
			}
		}
		assertTrue(act_country.matches(exp_country));
		
		System.out.println("RUNNING SUCCESFULLY");
	  
  }
  
  
  public void readFromExcel() {
	  try {
		FileInputStream file = new FileInputStream(new File("C:\\PROJECT/data.xlsx"));
		
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		
		XSSFSheet sheet = workbook.getSheetAt(0);
		String data = "";
		int totalRows = sheet.getLastRowNum();
		int totalCells = sheet.getRow(1).getLastCellNum();
		for(int r=1; r<=totalRows; r++) {
			XSSFRow currentRow = sheet.getRow(r);
			for(int c=0; c<totalCells; c++) {
				data += currentRow.getCell(c).toString()+";";
			}
		}
		
		
		String[] arr= data.split(";");
		username= arr[0];
		emailId = arr[1];
		password = arr[2];
	}
		

	 catch (Exception e) {
		System.out.println(e.getMessage());
	}
}
 
  @AfterTest
  public void afterTest() {
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	  driver.quit();
  }
  
  
}
